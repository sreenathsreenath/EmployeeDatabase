package com.java.ex;

public class NumberZeroException extends Exception {

	NumberZeroException() {}
	
	NumberZeroException(String error) {
		super(error);
	}
}
